import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cambiocon',
  templateUrl: './cambiocon.page.html',
  styleUrls: ['./cambiocon.page.scss'],
})
export class CambioconPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
