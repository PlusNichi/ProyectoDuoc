# Proyecto-Ionic

Al clonar en la terminal usar comando npm install
